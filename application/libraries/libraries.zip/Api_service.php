<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @author Aneesh
*/
/* Library service */

Class Api_service{
 
            
    public function get_nearest_location( $lat, $long, $count, $get_cords_only = true, $children = array(), $seo = "", $q, $emergency = false)
    {
            
        $CI = & get_instance();
        $CI->load->model('subscriber_model');
        $CI->load->model('category_model'); 
        
        $cords =  $CI->subscriber_model->get_nearest_location( $lat, $long, $count, $seo, $children, true, $q, $emergency);
        $ret = array();
        
        if($get_cords_only)
        {
            
            foreach ($cords as $c)
            {
                
                $category = $CI->category_model->fetchById($c->subs_cat_id);
            
                $val = array(
                    
                    'user_id' => $c->user_id,
                    'lat' => $c->lat,
                    'lon' => $c->lon,
                    'title' => $c->title,
                    'rating' => $c->subs_review,
                    'profile_visits' => $c->profile_visits,
                    'medical_center' => $c->subs_medical_center,
                    'cat' => $category->name,
                    'icon' => $this->get_gmap_caticon( 'doctors', $c->has_emergency, $c->is_visiting),
                    'img' => $c->subs_profile_img,

                );
                
                array_push($ret, $val);
                
            }
            
            return $ret;
            
        }
        
    }
    
    /*
     * Output stars based on rating
     * 
     */
    public static function get_stars_rating($number, $class = 'text-yellow')
    {    
        $rate = '';
        if($number == 0)
        {
            for($i = 1; $i <= 5; $i++)
            {
                $rate .= '<i class="fa fa-star-o text-muted"></i>';
            }
            
        }else{
            // Make it integer:
            $stars = round( $number * 2, 0, PHP_ROUND_HALF_UP);
            
            // Add full stars:
            $i = 1;
            while ($i <= $stars - 1) {
                $rate .= '<i class="fa fa-star '.$class.' "></i>';
                $i += 2;
            }
            // Add half star if needed:
            if ( $stars & 1 ) $rate .= '<i class="fa fa-star-half-full '.$class.' "></i>';
        }
        return $rate;
    } 
    
    
    public function get_nearest_pharmacies( $lat, $long, $count, $get_cords_only = true, $children = array(), $seo = "", $q, $emergency = false)
    {
            
        $CI = & get_instance();
        $CI->load->model('subscriber_model');
        $CI->load->model('category_model'); 
        
        $cords =  $CI->subscriber_model->get_nearest_pharmacies( $lat, $long, $count, $seo, $children, true, $q, $emergency);
        $ret = array();
        
        if($get_cords_only)
        {
            
            foreach ($cords as $c)
            {
                
                $category = $CI->category_model->fetchById($c->subs_cat_id);
                            
                $val = array(
                    
                    'user_id' => $c->user_id,
                    'lat' => $c->lat,
                    'lon' => $c->lon,
                    'title' => $c->title,
                    'rating' => $c->subs_review,
                    'profile_visits' => $c->profile_visits,
                    'cat' => $category->name,
                    'icon' => $this->get_gmap_caticon( 'pharmacies', false, false),
                    'img' => $c->subs_profile_img,

                );
                
                array_push($ret, $val);
                
            }
            
            return $ret;
            
        }
        
    }
    
    public function get_gmap_caticon( $master, $he = false, $travel = false)
    {
            
        switch($master)
        {
            case 'doctors' :  
                
                $icon = 'icn-gmap-dr.png';
                
                if($he)
                {
                    $icon = 'icn-gmap-dr-emergency.png';
                }
                
                if($travel)
                {
                    $icon = 'icn-gmap-dr-travel.png';
                }
                
            break; 
        
            case 'pharmacies' : $icon = 'icn-gmap-labs.png';
            break;
            
        }
        
        return $icon;
    }
    
    public static function get_subscriber_by_pk($id, $join = array())
    {
        $CI = & get_instance();
        $CI->load->model('subscriber_model');
        
        $join = array(
            array('table' => TBL_CATEGORY, 'condition' => TBL_CATEGORY.'.id_category = '.TBL_SUBSCRIBERS.'.subs_cat_id', 'join_type' => 'inner')
        );
        
        return $CI->subscriber_model->fetchById( $id, $join);
        
    }
    
    public function find_subscribers($params)
    {
        $CI = & get_instance();
        $CI->load->model('subscriber_model');
        $CI->load->library('category_service');

        return $CI->subscriber_model->findsm( $params, array());
    }
    
//    public function get_child_by_parent_seo($seo)
//    {
//        $CI = & get_instance();
//        $CI->load->model('category_model');
//        
//        return $CI->category_model->get_child_by_parent_seo( $seo);
//    }
        
}