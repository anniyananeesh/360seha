<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @author Aneesh
*/
/* Library service */

Class Patient_service{
 
    public static function get_patients( $condition = array(), $orderBy = array(), $limit = null, $offset = null, $join = array()){
        
        $CI = & get_instance();
        $CI->load->model('patient_model');
        
        $order_by = array(
          TBL_PATIENTS.'.id' => 'DESC'  
        );
        
        return $CI->patient_model->get( $condition, $order_by, $limit, $offset, $join);
 
    }
    
    public static function save($save, $where = array())
    {
        $CI = & get_instance();
        $CI->load->model('patient_model');
        
        return $CI->patient_model->save( $save, $where);
    }
    
    public static function get_patient_row($where = array(), $join = array())
    {
        $CI = & get_instance();
        $CI->load->model('patient_model');
        
        return $CI->patient_model->fetchRow($where, $join);
    }
    
    public static function get_patient_by_pk($id, $join = array())
    {
        $CI = & get_instance();
        $CI->load->model('patient_model');
        
        return $CI->patient_model->fetchById( $id, $join);
        
    }
    
    /*
     *  Unset product details from table
     * @params $where
     * 
     * For more doc ... See base_model
     */
    public static function unset_patient($where)
    {
        $CI = & get_instance();
        $CI->load->model('patient_model');
        
        return $CI->patient_model->delete($where);    
    }
    
    /*
     * Check if the username is already taken or not
     * @params $where
     * 
     * For more doc .. see base_model
     */
    public function has_username($where)
    {
        $user = $this->get_patients($where);
        
        if($user AND count($user) > 0)
        {
            return true;
        }else{
            
            return false;
        }
    }
    
    /*
     * Check patient login area
     * 
     */
    public function _auth( $post)
    {
        $CI = & get_instance();
        $CI->load->model('auth_model');
        $CI->load->library('encrypt');
        $CI->load->library('session');
        
        $email = $CI->security->xss_clean($post['uname']);
        $password = $CI->security->xss_clean($post['pwd']);
        
        $where = array( TBL_PATIENTS.'.email' => $email);
        
        $patient = $this->get_patient_row($where);
        
        if(count($patient) > 0 && $patient)
        {
            
            if($CI->auth_model->generate_password_hash($password, $patient->uniq_token) == $patient->pwd_hash)
            {
                if($patient->status == 1)
                {
                    $data['logged_public'] = array(

                        'user_id' => $CI->encrypt->encode($patient->id),
                        'name' => $patient->title,
                        'username' => $patient->email,
                        'type' => 'patient',
                        'validated' => true
                    );
                    
                    $CI->session->set_userdata($data);
                    return 'logged';//User logged
                    
                }else{
                    
                    return 'blocked'; //Status blocked
                }
            }else{
                return 'password'; // issue with the password typed;
            }
        }else{
            
            return 'user'; //No user has been found;
        }
        
    }
    
    /*
     * Reset n update the password
     * 
     */
    public function _rst( $id, $username){
        
        $CI = & get_instance();
        $CI->load->model('auth_model');
        
        $rndm_pwd = $CI->auth_model->generate_random_password();
        $uniq_token = $CI->auth_model->generate_unique_token($username);
        $pwd_hash = $CI->auth_model->generate_password_hash( $rndm_pwd, $uniq_token);
        
        $save = array(
          TBL_PATIENTS.'.pwd_hash' => $pwd_hash,
          TBL_PATIENTS.'.uniq_token' => $uniq_token,
          TBL_PATIENTS.'.r_password' => $rndm_pwd
        );
        
        $where = array(
          TBL_PATIENTS.'.id' => $id
        );
        
        $this->save( $save, $where);
	return $rndm_pwd;
    }
    
}